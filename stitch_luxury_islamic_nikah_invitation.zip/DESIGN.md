---
name: Ethereal Union
colors:
  surface: '#fff8f7'
  surface-dim: '#e4d7d7'
  surface-bright: '#fff8f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0f0'
  surface-container: '#f9ebea'
  surface-container-high: '#f3e5e5'
  surface-container-highest: '#eddfdf'
  on-surface: '#211a1a'
  on-surface-variant: '#504444'
  inverse-surface: '#362f2f'
  inverse-on-surface: '#fceded'
  outline: '#827473'
  outline-variant: '#d4c2c2'
  surface-tint: '#7b5455'
  primary: '#7b5455'
  on-primary: '#ffffff'
  primary-container: '#f4c2c2'
  on-primary-container: '#734e4e'
  inverse-primary: '#ecbaba'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#dfe0e0'
  on-secondary-container: '#616363'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#f1ca50'
  on-tertiary-container: '#6b5500'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad9'
  primary-fixed-dim: '#ecbaba'
  on-primary-fixed: '#2f1314'
  on-primary-fixed-variant: '#613d3e'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffe088'
  tertiary-fixed-dim: '#e9c349'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#574500'
  background: '#fff8f7'
  on-background: '#211a1a'
  surface-variant: '#eddfdf'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.15em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
---

## Brand & Style

The design system is centered on a royal, cinematic aesthetic tailored for a luxury Islamic Nikah invitation. The brand personality is deeply romantic, airy, and sophisticated, evoking an emotional response of serenity and high-end elegance. 

The style is a blend of **Minimalism** and **Glassmorphism**, moving away from heavy traditionalism toward a light, breathable composition. It utilizes generous whitespace, delicate floral motifs (Baby’s Breath), and soft glowing accents to create a sense of divine celebration. Transitions should feel like a slow-motion cinematic sequence—fluid, graceful, and intentional.

## Colors

The palette is anchored by a soft, elegant Blush Pink as the primary wash, symbolizing affection and grace. Pure White provides a clean, expansive secondary base that ensures the design feels "airy." Luxury Gold is reserved for accents—ornamental lines, iconography, and interactive highlights—to inject a royal character. Text is rendered in a warm, muted charcoal-brown (Neutral) rather than harsh black, maintaining the soft, romantic contrast of the interface.

## Typography

This design system employs a high-contrast typographic pairing to reinforce the "Royal" narrative. **Playfair Display** is used for all major headings and names; its high-contrast serifs provide a literary, timeless quality. **Plus Jakarta Sans** handles all body copy and functional labels, offering a contemporary, legible counterpoint that prevents the design from feeling dated.

For display titles, use tight letter-spacing to enhance the cinematic feel. For labels and dates, use expanded letter-spacing in uppercase to evoke the feeling of a premium physical invitation.

## Layout & Spacing

The layout follows a **Fixed Grid** model for desktop, centered to mimic the proportions of a physical wedding card. On mobile, it transitions to a fluid single-column layout with generous side margins. 

The spacing rhythm is intentionally "loose." Rather than packing information, use large vertical gaps (64px+) between sections to allow the floral patterns and background glows to breathe. Content should be vertically centered to maintain a balanced, editorial look.

## Elevation & Depth

Hierarchy is achieved through **Glassmorphism** and **Ambient Shadows**. Instead of solid cards, surfaces use a semi-transparent Pure White backdrop with a high-intensity backdrop blur (20px-40px). 

Shadows are extremely subtle, using a tinted "Gold-Dust" hue (a very low opacity version of #D4AF37) rather than grey. This creates a "glowing" effect rather than a "dropping" effect. Elements should feel as if they are floating on a soft bed of light.

## Shapes

The shape language is "Rounded," avoiding sharp edges to maintain the soft and romantic tone. Standard containers use a 0.5rem radius, while interactive elements like invitation buttons or RSVP inputs may use larger radii to feel more inviting. Decorative frames should utilize organic, floral-inspired clipping paths or subtle arched tops to mirror traditional Islamic architecture in a modernized, minimalist way.

## Components

### Buttons
Primary buttons use a Gold (#D4AF37) gradient with white text or a white background with a gold border. They should feature a soft "outer glow" hover effect rather than a color change.

### Cards & RSVP Panels
These are the centerpiece. Use semi-transparent white backgrounds with a delicate 1px border in 10% Gold. Backgrounds should feature faint, fixed-position floral overlays (Baby's Breath) that appear to sit behind the text but above the base layer.

### Inputs
RSVP text fields use a "minimalist line" style—only a bottom border in soft pink, which turns gold upon focus. The label floats elegantly above the line in uppercase.

### Floral Ornaments
Specific components for "Floral Dividers" should be used to separate sections. These are thin gold lines with a small Baby's Breath vector icon in the center.

### Smooth Animations
All components must enter the viewport via a "fade and slide up" motion with a long duration (0.8s) and a soft cubic-bezier easing to simulate cinematic grace.